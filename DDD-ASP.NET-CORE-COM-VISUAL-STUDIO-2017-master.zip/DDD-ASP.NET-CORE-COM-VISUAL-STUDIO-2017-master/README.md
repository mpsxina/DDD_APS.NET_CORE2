# DDD-ASP.NET-CORE-COM-VISUAL-STUDIO-2017
Nessa aula criaremos um projeto com DDD o mais simples possível, utilizando comandos do próprio Entity para salvar , alterar e excluir, e também demostrando como utilizar procedures com funções básicas de crud no projeto.
